﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.Azure;
using System.Configuration;

namespace AzureTableApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        AzureTable azureTable = new AzureTable();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void CreateTable_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (tableName.Text != null && !tableName.Text.Contains(" "))
                    azureTable.CreateAzureTable(tableName.Text);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error while creating table " + tableName.Text + "\nException: " + ex.Message);
            }
            //MessageBox.Show(tableName.Text);
        }

        private void addData_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var prodEntity = new Product
                {
                    ID = int.Parse(productId.Text),
                    Name = productName.Text,
                    Price = int.Parse(productPrice.Text),
                    Category = productCategory.Text
                };

                azureTable.AddDataIntoAzureTable(tableName.Text, prodEntity);

            }
            catch(Exception ex)
            {
                MessageBox.Show("Error while adding data to table " + tableName.Text + "\nException: "+ex.Message);
            }
            //MessageBox.Show(string.Format("ID:{0}, Name:{1}, Price:{2}, Category:{3}", productId.Text, productName.Text, productPrice.Text, productCategory.Text));
        }

        private void ListTable_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                azureTable.tableData(tableName.Text, productList);

            }
            catch(Exception ex)
            {
                MessageBox.Show("Error while listing data from table "+ tableName.Text);
            }
        }
    }


    /// <summary>
    /// Product class
    /// </summary>
    public class Product : TableEntity
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public int Price { get; set; }
    }
}
